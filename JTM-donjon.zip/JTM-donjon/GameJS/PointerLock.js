
const canvas = document.querySelector('canvas')

canvas.addEventListener('click', () => {
    canvas.requestPointerLock()
})




